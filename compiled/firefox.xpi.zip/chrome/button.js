CustomButton = {
  1: function () {
    var s = window.content.document.createElement('script');
    s.src = 'http://copper.is/tips/embed_iframe.js';
    window.content.document.body.appendChild(s);
  },
}